export const API_URL = "/api";
export default API_URL;

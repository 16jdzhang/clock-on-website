<template>
  <div class="settings-page">
    <div class="container page">
      <div class="row">
        <div class="col-md-6 offset-md-3 col-xs-12">
          
          <h1 class="text-xs-center">自动打卡参数</h1>
          <form @submit.prevent="updateAuto()">
            <fieldset>
              <fieldset class="form-group">
                <div class="form-control">
                  自动打卡当前状态：{{ workingState }}
                </div>
              </fieldset>
              <fieldset class="form-group">
                <input
                  class="form-control form-control-lg"
                  type="text"
                  v-model="username"
                  placeholder="校园网账号"
                />
              </fieldset>
              <fieldset class="form-group">
                <input
                  class="form-control form-control-lg"
                  type="password"
                  v-model="password"
                  placeholder="校园网密码"
                />
              </fieldset>
              <fieldset class="form-group">
                <div class="form-control">
                  打卡时间：
                  <input type="time" v-model="hour"/>
                </div>
              </fieldset>
              <fieldset class="form-group">
                <input
                  class="form-control"
                  type="number"
                  step="0.1"
                  placeholder="昨天下午体温"
                  v-model="afternoorBodyHeat"
                />
              </fieldset>
              <fieldset class="form-group">
                <input
                  class="form-control"
                  type="number"
                  step="0.1"
                  placeholder="今天上午体温"
                  v-model="forenoonBodyHeat"
                />
              </fieldset>
              <fieldset class="form-group">
                <div class="form-control">
                  咳嗽
                  <input type="radio" v-model="hasCough" value="true">有
                  <input type="radio" v-model="hasCough" value="false">无
                </div>
              </fieldset>
              <fieldset class="form-group">
                <div class="form-control">
                  气促
                  <input type="radio" v-model="hasShortBreath" value="true">有
                  <input type="radio" v-model="hasShortBreath" value="false">无
                </div>
              </fieldset>
              <fieldset class="form-group">
                <div class="form-control">
                  乏力
                  <input type="radio" v-model="hasWeak" value="true">有
                  <input type="radio" v-model="hasWeak" value="false">无
                </div>
              </fieldset>
              <fieldset class="form-group">
                <div class="form-control">
                  发烧
                  <input type="radio" v-model="hasFever" value="true">有
                  <input type="radio" v-model="hasFever" value="false">无
                </div>
              </fieldset>
              <fieldset class="form-group">
                <div class="form-control">
                  自动打卡
                  <input type="radio" v-model="start" value="true">启动
                  <input type="radio" v-model="start" value="false">关闭
                </div>
              </fieldset>
              <button class="btn btn-lg btn-primary pull-xs-right">
                Update 自动打卡参数
              </button>
            </fieldset>
          </form>
          <!-- Line break for logout button -->
          <hr />
          <h1 class="text-xs-center">Your Settings</h1>
          <form @submit.prevent="updateSettings()">
            <fieldset>
              <fieldset class="form-group">
                <input
                  class="form-control"
                  type="text"
                  v-model="currentUser.image"
                  placeholder="URL of profile picture"
                />
              </fieldset>
              <fieldset class="form-group">
                <input
                  class="form-control form-control-lg"
                  type="text"
                  v-model="currentUser.username"
                  placeholder="Your username"
                />
              </fieldset>
              <fieldset class="form-group">
                <textarea
                  class="form-control form-control-lg"
                  rows="8"
                  v-model="currentUser.bio"
                  placeholder="Short bio about you"
                ></textarea>
              </fieldset>
              <fieldset class="form-group">
                <input
                  class="form-control form-control-lg"
                  type="text"
                  v-model="currentUser.email"
                  placeholder="Email"
                />
              </fieldset>
              <fieldset class="form-group">
                <input
                  class="form-control form-control-lg"
                  type="password"
                  v-model="currentUser.password"
                  placeholder="Password"
                />
              </fieldset>
              <button class="btn btn-lg btn-primary pull-xs-right">
                Update Settings
              </button>
            </fieldset>
          </form>
          <!-- Line break for logout button -->
          <hr />
          <button @click="logout" class="btn btn-outline-danger">
            Or click here to logout.
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { LOGOUT, UPDATE_USER } from "@/store/actions.type";
import ApiService from "@/common/api.service";

export default {
  name: "RwvSettings",
  computed: {
    ...mapGetters(["currentUser"])
  },
  data() {
    return {
      hour: null,
      afternoorBodyHeat: null,
      forenoonBodyHeat: null,
      hasCough: null,
      hasShortBreath: null,
      hasWeak: null,
      hasFever: null,
      workingState: "无",
      start: false,
      username: null,
      password: null
    }
  },
  methods: {
    updateSettings() {
      this.$store.dispatch(UPDATE_USER, this.currentUser).then(() => {
        // #todo, nice toast and no redirect
        this.$router.push({ name: "home" });
      });
    },
    logout() {
      this.$store.dispatch(LOGOUT).then(() => {
        this.$router.push({ name: "home" });
      });
    },
    updateAuto() {
      ApiService.put("auto", {
        auto:{
          hour: this.hour,
          afternoorBodyHeat: this.afternoorBodyHeat,
          forenoonBodyHeat: this.forenoonBodyHeat,
          hasCough: this.hasCough,
          hasShortBreath: this.hasShortBreath,
          hasWeak: this.hasWeak,
          hasFever: this.hasFever,
          start: this.start,
          username: this.username,
          password: this.password
      }}).then(({ data }) => {
        if(data.success){
          this.getAuto();
        }
      }).catch((e)=>{
        console.log(e.response.data);
      })
    },
    getAuto() {
      ApiService.get("auto").then(({ data }) => {
        this.hour = data.hour;
        this.afternoorBodyHeat = data.afternoorBodyHeat;
        this.forenoonBodyHeat = data.forenoonBodyHeat;
        this.hasCough = data.hasCough;
        this.hasShortBreath = data.hasShortBreath;
        this.hasWeak = data.hasWeak;
        this.hasFever = data.hasFever;
        this.workingState = data.workingState;
        this.start = data.start;
        this.username = data.username;
      }).catch((e)=>{
        console.log(e);
      });
    }
  },
  created() {
    this.getAuto();
  }
};
</script>

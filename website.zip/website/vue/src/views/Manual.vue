<template>
  <div class="article-page">
    <div class="banner">
      <div class="container">
        <h1>{{ article.title }}</h1>
      </div>
    </div>
    <div class="container page">
      <div class="row article-content">
        <div class="col-xs-12">
          <div v-html="parseMarkdown(article.body)"></div>
        </div>
      </div>
      <hr />
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import marked from "marked";
import store from "@/store";
import { FETCH_ARTICLE, FETCH_COMMENTS } from "@/store/actions.type";

export default {
  name: "manual",
  data() {
    return {
      article: {
        title: "使用说明",
        body: `
## 介绍

这是一个每天帮你自动到校园网打卡的网站。眼看疫情还是很严重。使用http和https访问都可以，使用https时会提醒不安全，选继续前往就行。

## 注册

点击“Sign up”，开始注册。

![image-20200804205504469](img/md/image-20200804205504469.png)

输入所需信息注册。填入邮箱后点击发送验证码，然后登录自己的邮箱获取验证码，把验证码填过来。输入两次密码。

![image-20200804205912090](img/md/image-20200804205912090.png)

## 登录

登录可以是密码登录或者验证码登录。

![image-20200804210029229](img/md/image-20200804210029229.png)

登录后会自动跳到设置页面。

## 设置

请完整填完所有信息，以免系统打卡失败。选择“自动打卡”的“开启”。填完点击“Update 自动打卡参数”。

![image-20200804210513916](img/md/image-20200804210513916.png)

![image-20200804210610706](img/md/image-20200804210610706.png)

如果顺利的话，系统会是这样的

![image-20200804210901346](img/md/image-20200804210901346.png)

![image-20200804211124266](img/md/image-20200804211124266.png)

## 获取打卡报告

系统每一天如果成功打卡的话，会发邮件告知你。

邮件的内容是打卡后的html代码和打卡后刷新的html代码。

建议使用qq邮箱，微信有提醒。

## 其他功能

这个网站是在别人的网站上进行二次开发的，其他一些像发帖的功能就自己探索了。

## 赞助作者

各位大佬给点电费吧。

![微信图片_20200804211827](img/md/20200804211827.png)
`,
      },
    }
  },
  methods: {
    parseMarkdown(content) {
      return marked(content);
    }
  }
};
</script>

<template>
  <div class="auth-page">
    <div class="container page">
      <div class="row">
        <div class="col-md-6 offset-md-3 col-xs-12">
          <h1 class="text-xs-center">Sign in</h1>
          <p class="text-xs-center">
            <router-link :to="{ name: 'login' }">
              点这里转为密码登录
            </router-link>
          </p>
          <!-- <ul v-if="errors" class="error-messages">
            <li v-for="(v, k) in errors" :key="k">{{ k }} {{ v | error }}</li>
          </ul> -->
          <ul v-if="my_errors"  class="error-messages">
            <li>{{ my_errors }}</li>
          </ul>
          <form @submit.prevent="onSubmit(email, password)">
            <fieldset class="form-group">
              <input
                class="form-control form-control-lg"
                type="text"
                v-model="email"
                placeholder="Email"
              />
            </fieldset>
            <fieldset class="form-group">
              <button class="btn btn-lg btn-primary" :disabled="isButtonDisabled" @click.prevent="onSendVerification">
                {{btn_verify}}
              </button>
            </fieldset>
            <fieldset class="form-group">
              <input
                class="form-control form-control-lg"
                type="text"
                v-model="password"
                placeholder="验证码"
              />
            </fieldset>
            <button class="btn btn-lg btn-primary pull-xs-right">
              Sign in
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { LOGIN } from "@/store/actions.type";
import { SET_AUTH, SET_ERROR } from "@/store/mutations.type";
import ApiService from "@/common/api.service";

export default {
  name: "RwvLogin2",
  data() {
    return {
      email: null,
      password: null,
      isButtonDisabled: false,
      btn_verify: "发送验证码",
      my_errors: null,
    };
  },
  methods: {
    onSubmit(email, password) {
      new Promise(resolve => {
        ApiService.post("verify/login", { user: {email, password} })
        .then(({ data }) => {
          this.$store.commit(SET_AUTH, data.user);
          resolve(data);
        })
        .catch(({ response }) => {
          this.$store.commit(SET_ERROR, response.data.errors);
          this.my_errors = JSON.stringify(response.data.errors);
        });
      }).then(() => this.$router.push({ name: "settings" }));
    },
    onSendVerification() {
      ApiService.post("verify/loginEmail", { verify: {email: this.email} })
        .then(({ data }) => {
          if(data.success === undefined || data.success===false){
            throw Error('success = false');
          }
          this.isButtonDisabled = true;
          var second = 60;
          var render = ()=>{
            this.btn_verify = `已发送验证码${second}`;
          };
          render();
          var clock = ()=>{
            setTimeout(()=>{
              if (second>0){
                second = second-1;
                render();
                clock();
              }
              else{
                this.btn_verify = "发送验证码";
                this.isButtonDisabled = false;
              }
            }, 1000);
          };
          clock();
        })
        .catch(({ response }) => {
          this.$store.commit(SET_ERROR, response.data.errors);
          this.my_errors = JSON.stringify(response.data.errors);
        });
    }
  },
  computed: {
    ...mapState({
      errors: state => state.auth.errors
    })
  }
};
</script>

<template>
  <div class="auth-page">
    <div class="container page">
      <div class="row">
        <div class="col-md-6 offset-md-3 col-xs-12">
          <h1 class="text-xs-center">Sign up</h1>
          <p class="text-xs-center">
            <router-link :to="{ name: 'login' }">
              Have an account?
            </router-link>
          </p>
          <!-- <ul v-if="errors" class="error-messages">
            <li v-for="(v, k) in errors" :key="k">{{ k }} {{ v | error }}</li>
          </ul> -->
          <ul v-if="my_errors"  class="error-messages">
            <li>{{ my_errors }}</li>
          </ul>
          <form @submit.prevent="onSubmit">
            <fieldset class="form-group">
              <input
                class="form-control form-control-lg"
                type="text"
                v-model="username"
                placeholder="Username"
              />
            </fieldset>
            <fieldset class="form-group">
              <input
                class="form-control form-control-lg"
                type="text"
                v-model="email"
                placeholder="Email"
              />
            </fieldset>
            <fieldset class="form-group">
              <button class="btn btn-lg btn-primary" :disabled="isButtonDisabled" @click.prevent="onSendVerification">
                {{btn_verify}}
              </button>
            </fieldset>
            <fieldset class="form-group">
              <input
                class="form-control form-control-lg"
                type="text"
                v-model="verification"
                placeholder="验证码"
              />
            </fieldset>
            <fieldset class="form-group">
              <input
                class="form-control form-control-lg"
                type="password"
                v-model="password"
                placeholder="Password"
              />
            </fieldset>
            <fieldset class="form-group">
              <input
                class="form-control form-control-lg"
                type="password"
                v-model="password2"
                placeholder="Password Again"
              />
            </fieldset>
            <button class="btn btn-lg btn-primary pull-xs-right">
              Sign up
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { REGISTER } from "@/store/actions.type";
import { SET_ERROR } from "@/store/mutations.type";
import ApiService from "@/common/api.service";

export default {
  name: "RwvRegister",
  data() {
    return {
      username: "",
      email: "",
      password: "",
      password2: "",
      verification: "",
      btn_verify: "发送验证码",
      isButtonDisabled: false,
      my_errors: null,
    };
  },
  computed: {
    ...mapState({
      errors: state => state.auth.errors
    })
  },
  methods: {
    onSubmit() {
      if (this.password === this.password2){
        this.$store
          .dispatch(REGISTER, {
            email: this.email,
            password: this.password,
            username: this.username,
            code: this.verification
          })
          .then(() => this.$router.push({ name: "home" }))
          .catch((e) => {
            if(e.response){
              e = e.response.data.errors;
              this.my_errors = JSON.stringify(e);
            }
          });
      }
      else{
        this.my_errors = "两次密码不一致" ;
          this.$store.commit(SET_ERROR, {password: "两次密码不一致"});
      }
    },
    onSendVerification() {
      ApiService.post("verify", { verify: {email: this.email} })
        .then(({ data }) => {
          if(data.success === undefined || data.success===false){
            throw Error('success = false');
          }
          this.isButtonDisabled = true;
          var second = 60;
          var render = ()=>{
            this.btn_verify = `已发送验证码${second}`;
          };
          render();
          var clock = ()=>{
            setTimeout(()=>{
              if (second>0){
                second = second-1;
                render();
                clock();
              }
              else{
                this.btn_verify = "发送验证码";
                this.isButtonDisabled = false;
              }
            }, 1000);
          };
          clock();
        })
        .catch(({ response }) => {
          this.$store.commit(SET_ERROR, response.data.errors);
          this.my_errors = JSON.stringify(response.data.errors);
        });
    }
  }
};
</script>

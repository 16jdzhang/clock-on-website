## 介绍

这是一个每天帮你自动到校园网打卡的网站。眼看疫情还是很严重。

## 注册

点击“Sign up”，开始注册。

![image-20200804205504469](D:\fold\NEW_AUTO\vue-realworld-example-app-master\public\img\md\image-20200804205504469.png)

输入所需信息注册。填入邮箱后点击发送验证码，然后登录自己的邮箱获取验证码，把验证码填过来。输入两次密码。

![image-20200804205912090](D:\fold\NEW_AUTO\vue-realworld-example-app-master\public\img\md\image-20200804205912090.png)

## 登录

登录可以是密码登录或者验证码登录。

![image-20200804210029229](D:\fold\NEW_AUTO\vue-realworld-example-app-master\public\img\md\image-20200804210029229.png)

登录后会自动跳到设置页面。

## 设置

请完整填完所有信息，以免系统打卡失败。选择“自动打卡”的“开启”。填完点击“Update 自动打卡参数”。

![image-20200804210513916](D:\fold\NEW_AUTO\vue-realworld-example-app-master\public\img\md\image-20200804210513916.png)

![image-20200804210610706](D:\fold\NEW_AUTO\vue-realworld-example-app-master\public\img\md\image-20200804210610706.png)

如果顺利的话，系统会是这样的

![image-20200804210901346](D:\fold\NEW_AUTO\vue-realworld-example-app-master\public\img\md\image-20200804210901346.png)

![image-20200804211124266](D:\fold\NEW_AUTO\vue-realworld-example-app-master\public\img\md\image-20200804211124266.png)

## 获取打卡报告

系统每一天如果成功打卡的话，会发邮件告知你。

邮件的内容是打卡后的html代码和打卡后刷新的html代码。

建议使用qq邮箱，微信有提醒。

## 赞助作者

各位大佬给点电费吧。

![微信图片_20200804211827](D:\fold\NEW_AUTO\vue-realworld-example-app-master\public\img\md\微信图片_20200804211827.jpg)
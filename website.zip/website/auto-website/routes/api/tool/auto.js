var mongoose = require('mongoose');
var Auto = mongoose.model('Auto');
var User = mongoose.model('User');

var puppeteer = require('puppeteer-core');
var mail = require('./mail').mail;

var new_loop = function(id, trigger_time, cb){
    var loop = async()=>{
        const hour = trigger_time;
        var today = new Date(Date.now());
        today = new Date(`${today.getFullYear()}-${today.getMonth()+1}-${today.getDate()}`);
        var try_again = function(time){
            var timer = setTimeout(loop, time);
            set_timer(id, timer);
        }
        var tomorrow_again = async()=>{
            var date_json = {latest:`${today.getFullYear()}-${today.getMonth()+1}-${today.getDate()}`};
            // fs.writeFileSync(date_file_name, JSON.stringify(date_json));
            var auto = await Auto.findOne({user: id});
            auto.date = JSON.stringify(date_json);
            await auto.save();
            var tomorrow = new Date(today.getTime()+24*60*60*1000);
            tomorrow = new Date(`${tomorrow.getFullYear()}-${tomorrow.getMonth()+1}-${tomorrow.getDate()} ${hour}`)
            tomorrow = tomorrow.getTime()-Date.now();
            try_again(tomorrow);
        }
        try{
            // var date_json = fs.readFileSync(date_file_name);
            var auto = await Auto.findOne({user: id});
            var date_json = auto.date;
            date_json = JSON.parse(date_json);
            if (!(date_json.latest)){
                throw 'no latest';
            }
            var last = new Date(date_json.latest);
            if (last<today){
                throw 'clock on';
            }
            else{
                tomorrow_again();
            }
        }
        catch(e){
            var now = new Date(Date.now());
            var time = new Date(`${today.getFullYear()}-${today.getMonth()+1}-${today.getDate()}  ${hour}`);
            if (now<time){
                try_again(time.getTime()-now.getTime());
            }
            else{
                await cb(tomorrow_again, try_again, today);
            }
        }
    };
    return loop;
};

var clock_on = async(page, account, formData)=>{
    
    await page.goto('https://my.stu.edu.cn/health-report/report/report.do');

    // await page.waitForNavigation();

    await (await page.$('[href=init-stu-user]')).click();

    await page.waitForNavigation();

    await (await page.$('#username')).type(account.username);
    await (await page.$('#password')).type(account.password);
    await (await page.$('#login')).click();
    
    await page.waitForNavigation();

    // <input type="number" name="dailyReport.afternoorBodyHeat" value="36.8" style="width: 50px" require_d=""></input>
    await page.$eval('input[name="dailyReport.afternoorBodyHeat"]',input => input.value='' );
    await (await page.$('input[name="dailyReport.afternoorBodyHeat"]')).type(`${formData[0]}`);
    // <input type="number" name="dailyReport.forenoonBodyHeat" value="36.8" style="width: 50px" require_d=""></input>
    await page.$eval('input[name="dailyReport.forenoonBodyHeat"]',input => input.value='' );
    await (await page.$('input[name="dailyReport.forenoonBodyHeat"]')).type(`${formData[1]}`);
    // <input type="radio" name="dailyReport.hasCough" value="false" checked="checked"></input>
    await page.click(`input[type="radio"][name="dailyReport.hasCough"][value="${formData[2]}"]`);
    // <input type="radio" name="dailyReport.hasShortBreath" value="false" checked="checked"></input>
    await page.click(`input[type="radio"][name="dailyReport.hasShortBreath"][value="${formData[3]}"]`);
    // <input type="radio" name="dailyReport.hasWeak" value="false" checked="checked"></input>
    await page.click(`input[type="radio"][name="dailyReport.hasWeak"][value="${formData[4]}"]`);
    // <input type="radio" name="dailyReport.hasFever" value="false" checked="checked"></input>
    await page.click(`input[type="radio"][name="dailyReport.hasFever"][value="${formData[5]}"]`);

    // <button id="submitBtn3" class="active">提交健康信息</button>
    await page.click('#submitBtn3');

    // <div id="noticeMsg" align="center"></div>
    // <div id="noticeMsg" align="center" style="display: block;">今天(06月17日)数据已上报成功!</div>
    await page.waitForSelector('#noticeMsg[style="display: block;"]');
};

var timer_pool = {};

var set_timer = function(id, timer){
    timer_pool[id] = timer;
};

var stop = function(id){
    if(timer_pool[id]){
        clearTimeout(timer_pool[id]);
        delete timer_pool[id];
    }
};

var state = function(id){
    if(timer_pool[id]){
        return true;
    }
    else{
        return false;
    }
};

var opt = {};
var init = function(opt_){
    opt = opt_;
    Auto.find().then((autos)=>{
        for(var a of autos){
            if(a.start){
                start(a.user);
            }
        }
    });
};

var start = async(id)=>{
    var auto = await Auto.findOne({user: id});
    if(!auto){
        throw Error('wrong id');
    }
    if(auto.hour === null){
        throw Error('without hour');
    }
    if(auto.username === null){
        throw Error('without username');
    }
    if(auto.password === null){
        throw Error('without password');
    }
    if(auto.afternoorBodyHeat === null){
        throw Error('without afternoorBodyHeat');
    }
    if(auto.forenoonBodyHeat === null){
        throw Error('without forenoonBodyHeat');
    }
    if(auto.hasCough === null){
        throw Error('without hasCough');
    }
    if(auto.hasShortBreath === null){
        throw Error('without hasShortBreath');
    }
    if(auto.hasWeak === null){
        throw Error('without hasWeak');
    }
    if(auto.hasFever === null){
        throw Error('without hasFever');
    }
    var user = await User.findById(id);
    if(user.email === null){
        throw Error('without email');
    }
    await new_loop(id, auto.hour, async(tomorrow_again, try_again, today)=>{
        const browser = await puppeteer.launch(opt);
        const page = await browser.newPage();
        await page.setDefaultNavigationTimeout(0);
        try{
            await clock_on(page, {
                username: auto.username,
                password: auto.password,
            }, [
                auto.afternoorBodyHeat,
                auto.forenoonBodyHeat,
                auto.hasCough,
                auto.hasShortBreath,
                auto.hasWeak,
                auto.hasFever
            ]);
            tomorrow_again();
            var html = '';
            html += await page.content();
            await page.reload();
            html += await page.content();
            mail({
                from: '自动打卡', 
                to: user.email, 
                subject: '打卡报告', 
                text: '今日打卡', 
                html
            })
        }
        catch(e){
            mail({
                from: '自动打卡', 
                to: user.email, 
                subject: '打卡报告', 
                text: '今日打卡', 
                html: '今天好像出了点问题，请联系管理员。以下是错误信息：'+e.toString()
            })
        }
        finally{
            browser.close();
        }
    })();
};

module.exports = {
    start, stop, state, init
}
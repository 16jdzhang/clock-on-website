var  nodemailer = require("nodemailer");
var smtpTransport = require('nodemailer-smtp-transport');
var wellknown = require("nodemailer-wellknown");
var config = wellknown("QQ");
const new_mail = function(user, pass){
    config.auth = {
        user,
        pass
    }
    var transporter = nodemailer.createTransport(smtpTransport(config));

    return function({from, to, subject, text, html}){
    
        var mailOptions = {
            from:`${from}<${user}>`,
            to,
            subject,
            text,
            html
        };
    
        return new Promise((res, rej)=>{
            transporter.sendMail(mailOptions, function(error, info){
                if(error){
                    rej(error);
                }
                else{
                    res();
                }
            });
        })
    };
};

var mail_ = null;

var init = function(user, pass){
    mail_ = new_mail(user, pass);
}

var mail = function(arg){
    if (mail_ != null){
        return mail_(arg);
    }
}

module.exports = {
    new_mail,
    mail,
    init
};
var mongoose = require('mongoose');
var router = require('express').Router();
var passport = require('passport');
var User = mongoose.model('User');
var auth = require('../auth');

var Verify = mongoose.model('Verify');
var Auto = mongoose.model('Auto');
var mail = require('./tool/mail').mail;
var auto_ = require('./tool/auto');
//获取用户信息
router.get('/user', auth.required, function(req, res, next){
  User.findById(req.payload.id).then(function(user){
    if(!user){ return res.sendStatus(401); }

    return res.json({user: user.toAuthJSON()});
  }).catch(next);
});
//设置个人信息
router.put('/user', auth.required, function(req, res, next){
  User.findById(req.payload.id).then(function(user){
    if(!user){ return res.sendStatus(401); }

    // only update fields that were actually passed...
    if(typeof req.body.user.username !== 'undefined'){
      user.username = req.body.user.username;
    }
    if(typeof req.body.user.email !== 'undefined'){
      user.email = req.body.user.email;
    }
    if(typeof req.body.user.bio !== 'undefined'){
      user.bio = req.body.user.bio;
    }
    if(typeof req.body.user.image !== 'undefined'){
      user.image = req.body.user.image;
    }
    if(typeof req.body.user.password !== 'undefined'){
      user.setPassword(req.body.user.password);
    }

    return user.save().then(function(){
      return res.json({user: user.toAuthJSON()});
    });
  }).catch(next);
});
//登录
router.post('/users/login', function(req, res, next){
  if(!req.body.user.email){
    return res.status(422).json({errors: {email: "can't be blank"}});
  }

  if(!req.body.user.password){
    return res.status(422).json({errors: {password: "can't be blank"}});
  }
  
  req.body.user.password = JSON.stringify({type: 'users', password: req.body.user.password});

  passport.authenticate('local', {session: false}, function(err, user, info){
    if(err){ return next(err); }

    if(user){
      user.token = user.generateJWT();
      return res.json({user: user.toAuthJSON()});
    } else {
      return res.status(422).json(info);
    }
  })(req, res, next);
});
//创建用户
router.post('/users', function(req, res, next){
  var createUser = ()=>{
    var user = new User();

    user.username = req.body.user.username;
    user.email = req.body.user.email;
    user.setPassword(req.body.user.password);

    user.save().then(function(){
      return res.json({user: user.toAuthJSON()});
    }).catch(next);
  };
  Verify.findOne({email: req.body.user.email}).then(function(verify){
    if(!verify){
      return res.status(422).json({errors: {verify: "没有该邮箱的验证码"}});
    }
    if(verify.code.toString() === req.body.user.code){
      verify.remove();
      createUser();
    }
    else{
      return res.status(422).json({errors: {verify: "验证码错误"}});
    }
  }).catch(next);
});
//发送邮箱验证码
router.post('/verify', function(req, res, next){
  var sendEmail = ()=>{
    var verify = new Verify();
    verify.email = req.body.verify.email;
    verify.code = mongoose.Types.ObjectId();
    verify.save().then(function(){
        //send email
        mail({
          from: '自动打卡', 
          to: verify.email, 
          subject: '注册邮箱验证', 
          text: '验证码', 
          html: `你好，有人以你的邮箱在我站注册，现在通过验证码验证。验证码是“ <strong>${verify.code.toString()}</strong> ”。`
        }).then(()=>{
          return res.json({success: true});
        }).catch(()=>{
          return res.status(422).json({errors: {verify: "请输入有效邮箱"}});
        });
    }).catch(next);
  };
  Verify.findOne({email: req.body.verify.email}).then(function(verify){
    if(!verify){
      sendEmail();
    }
    else{
      verify.remove().then(sendEmail);
    }
  }).catch(next);
});
//登录
router.post('/verify/login', function(req, res, next){
  if(!req.body.user.email){
    return res.status(422).json({errors: {email: "can't be blank"}});
  }

  if(!req.body.user.password){
    return res.status(422).json({errors: {password: "can't be blank"}});
  }

  req.body.user.password = JSON.stringify({type: 'verify', password: req.body.user.password});

  passport.authenticate('local', {session: false}, function(err, user, info){
    if(err){ return next(err); }

    if(user){
      user.token = user.generateJWT();
      return res.json({user: user.toAuthJSON()});
    } else {
      return res.status(422).json(info);
    }
  })(req, res, next);
});
//发送邮箱验证码
router.post('/verify/loginEmail', function(req, res, next){
  var sendEmail = ()=>{
    var verify = new Verify();
    verify.email = req.body.verify.email;
    verify.code = mongoose.Types.ObjectId();
    verify.save().then(function(){
        //send email
        mail({
          from: '自动打卡', 
          to: verify.email, 
          subject: '登录邮箱验证', 
          text: '验证码', 
          html: `你好，有人以你的邮箱在我站登录，现在通过验证码验证。验证码是“ <strong>${verify.code.toString()}</strong> ”。`
        }).then(()=>{
          return res.json({success: true});
        }).catch(next);
    }).catch(()=>{
      return res.status(422).json({errors: {verify: "请输入有效邮箱"}});
    });
  };
  Verify.findOne({email: req.body.verify.email}).then(function(verify){
    if(!verify){
      sendEmail();
    }
    else{
      verify.remove().then(sendEmail);
    }
  }).catch(next);
});
//设置打卡信息
router.put('/auto', auth.required, function(req, res, next){
  Auto.findOne({ user: req.payload.id }).then(function(auto){
    if(!auto){
      auto = new Auto();
      auto.user = req.payload.id;
    }
    if(typeof req.body.auto.hour !== 'undefined'){
      auto.hour = req.body.auto.hour;
    }
    if(typeof req.body.auto.afternoorBodyHeat !== 'undefined'){
      auto.afternoorBodyHeat = req.body.auto.afternoorBodyHeat;
    }
    if(typeof req.body.auto.forenoonBodyHeat !== 'undefined'){
      auto.forenoonBodyHeat = req.body.auto.forenoonBodyHeat;
    }
    if(typeof req.body.auto.hasCough !== 'undefined'){
      auto.hasCough = req.body.auto.hasCough;
    }
    if(typeof req.body.auto.hasShortBreath !== 'undefined'){
      auto.hasShortBreath = req.body.auto.hasShortBreath;
    }
    if(typeof req.body.auto.hasWeak !== 'undefined'){
      auto.hasWeak = req.body.auto.hasWeak;
    }
    if(typeof req.body.auto.hasFever !== 'undefined'){
      auto.hasFever = req.body.auto.hasFever;
    }
    if(typeof req.body.auto.start !== 'undefined'){
      auto.start = req.body.auto.start;
    }
    if(typeof req.body.auto.username !== 'undefined'){
      auto.username = req.body.auto.username;
    }
    if(typeof req.body.auto.password !== 'undefined'){
      if(req.body.auto.password !== null && req.body.auto.password !== ''){
        auto.password = req.body.auto.password;
      }
    }
    if(!auto.start){
      auto.start = false;
    }
    else{
      auto.start = true;
    }
    var state = auto_.state(req.payload.id);
    if(auto.start && !state){
      auto.save().then(function(){
        auto_.start(req.payload.id).then(()=>{
          res.json({success: true});
        }).catch((e)=>{
          res.status(422).json({errors: {auto: e.toString()}});
        });
      }).catch((e)=>{
        res.status(422).json({errors: {auto: e.toString()}});
      });
    }
    if(!auto.start && state){
      auto_.stop(req.payload.id);
    }
    return auto.save().then(function(){
      return res.json({success: true});
    });
  }).catch(next);
});
//获取打卡信息
router.get('/auto', auth.required, function(req, res, next){
  Auto.findOne({ user: req.payload.id }).then(function(auto){
    if(!auto){
      return res.status(422).json({errors: {auto: "没有设置打卡信息"}});
    }
    if(!auto.start){
      auto.start = false;
    }
    var workingState = "测试";
    var state = auto_.state(req.payload.id);
    if(state){
      workingState = "正在运行";
    }
    else{
      workingState = "停止运行";
    }
    return res.json({
      hour: auto.hour,
      afternoorBodyHeat: auto.afternoorBodyHeat,
      forenoonBodyHeat: auto.forenoonBodyHeat,
      hasCough: auto.hasCough,
      hasShortBreath: auto.hasShortBreath,
      hasWeak: auto.hasWeak,
      hasFever: auto.hasFever,
      start: auto.start,
      username: auto.username,
      workingState
    });
  }).catch(next);
});
module.exports = router;

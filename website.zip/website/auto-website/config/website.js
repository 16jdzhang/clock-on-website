var mail = require('../routes/api/tool/mail');
mail.init('510481609@qq.com', 'ntthtzplaohfcaia');

var auto = require('../routes/api/tool/auto');
auto.init({
    executablePath:'/usr/bin/chromium-browser',
    args: ['--no-sandbox']
})

const https = require('https');
const fs = require('fs');

const options = {
  key: fs.readFileSync('config/key.pem'),
  cert: fs.readFileSync('config/cert.pem')
};

var start_https = function(app){
    https.createServer(options, app).listen(443);
}

module.exports = { start_https };
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var mongoose = require('mongoose');
var User = mongoose.model('User');
var Verify = mongoose.model('Verify');

passport.use(new LocalStrategy({
  usernameField: 'user[email]',
  passwordField: 'user[password]'
}, function(email, passwordJSON, done) {
  var { type, password } = JSON.parse(passwordJSON);
  if(type === 'users'){
    User.findOne({email: email}).then(function(user){
      if(!user || !user.validPassword(password)){
        return done(null, false, {errors: {'email or password': 'is invalid'}});
      }
      return done(null, user);
    }).catch(done);
  }
  if(type === 'verify'){
    Verify.findOne({email: email}).then(function(verify){
      if(!verify || !(verify.code.toString() === password)){
        return done(null, false, {errors: {'email or 验证码': 'is invalid'}});
      }

      User.findOne({email: email}).then(function(user){
        if(!user){
          return done(null, false, {errors: {'email': 'is invalid'}});
        }
        return done(null, user);
      }).catch(done);
    }).catch(done);
  }
}));


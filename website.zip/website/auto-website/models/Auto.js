var mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

var AutoSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User',  unique: true, index: true},
  hour: String,
  afternoorBodyHeat: Number,
  forenoonBodyHeat: Number,
  hasCough: Boolean,
  hasShortBreath: Boolean,
  hasWeak: Boolean,
  hasFever: Boolean,
  start: Boolean,
  date: String,
  username: String,
  password: String,
});

AutoSchema.plugin(uniqueValidator, {message: 'is already taken.'});

mongoose.model('Auto', AutoSchema);
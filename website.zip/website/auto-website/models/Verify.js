var mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

var VerifySchema = new mongoose.Schema({
    email: {type: String, lowercase: true, unique: true, required: [true, "can't be blank"], match: [/\S+@\S+\.\S+/, 'is invalid'], index: true},
    code: { type: mongoose.Schema.Types.ObjectId},
    createAt: { type: Date, default: Date.now, index:{ expires: 300 }}
});

VerifySchema.plugin(uniqueValidator, {message: 'is already taken.'});

mongoose.model('Verify', VerifySchema);